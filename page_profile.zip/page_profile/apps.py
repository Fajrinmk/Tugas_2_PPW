from django.apps import AppConfig


class PageProfileConfig(AppConfig):
    name = 'page_profile'
